# Hospital VM API Documentation

## Base URL
```
http://localhost:8080/api
```

---

## Authentication Endpoints (`/auth`)

### 1. Login - Get JWT Token
**POST** `/api/auth/login`
- **Access**: Public (no authentication required)
- **Description**: Authenticate user and receive JWT token
- **URL**: http://localhost:8080/api/auth/login

**Request Body:**
```json
{
  "username": "admin",
  "password": "password123"
}
```

**Response (Success - 200):**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "username": "admin",
  "role": "ROLE_ADMIN",
  "message": "Login successful"
}
```

**Response (Error - 401):**
```json
{
  "message": "Invalid username or password"
}
```

---

### 2. Validate Token
**POST** `/api/auth/validate`
- **Access**: Public
- **Description**: Validate if JWT token is still valid
- **URL**: http://localhost:8080/api/auth/validate
- **Header**: `Authorization: Bearer {token}`

**Response (Valid - 200):**
```json
{
  "username": "admin",
  "message": "Token is valid"
}
```

**Response (Invalid - 401):**
```json
{
  "message": "Token is expired"
}
```

---

### 3. Test Auth Endpoint
**GET** `/api/auth/test`
- **Access**: Public
- **Description**: Test if auth API is working
- **URL**: http://localhost:8080/api/auth/test

**Response:**
```json
{
  "message": "Auth API is working!"
}
```

---

## User Management Endpoints (`/user`)

### 1. Get User Profile
**GET** `/api/user/profile`
- **Access**: Authenticated (USER, ADMIN)
- **Description**: Get current authenticated user profile
- **URL**: http://localhost:8080/api/user/profile
- **Header**: `Authorization: Bearer {token}`

---

### 2. Register New User
**POST** `/api/user/register`
- **Access**: Public
- **Description**: Register a new user account
- **URL**: http://localhost:8080/api/user/register

**Request Body:**
```json
{
  "username": "newuser",
  "password": "password123",
  "role": "USER"
}
```

**Response (Success - 201):**
```json
"User registered successfully"
```

---

### 3. Get All Users
**GET** `/api/user/all`
- **Access**: Admin only
- **Description**: Retrieve all users in system
- **URL**: http://localhost:8080/api/user/all
- **Header**: `Authorization: Bearer {admin_token}`

**Response:**
```json
[
  {
    "id": 1,
    "username": "admin",
    "role": "ADMIN"
  },
  {
    "id": 2,
    "username": "user1",
    "role": "USER"
  }
]
```

---

### 4. Get User by ID
**GET** `/api/user/{id}`
- **Access**: Admin only
- **Description**: Get specific user details
- **URL**: http://localhost:8080/api/user/1
- **Header**: `Authorization: Bearer {admin_token}`

---

### 5. Update User
**PUT** `/api/user/{id}`
- **Access**: Admin only
- **Description**: Update user information
- **URL**: http://localhost:8080/api/user/1
- **Header**: `Authorization: Bearer {admin_token}`

**Request Body:**
```json
{
  "username": "updated_user",
  "role": "ADMIN"
}
```

---

### 6. Delete User
**DELETE** `/api/user/{id}`
- **Access**: Admin only
- **Description**: Delete a user account
- **URL**: http://localhost:8080/api/user/1
- **Header**: `Authorization: Bearer {admin_token}`

---

### 7. Change Password
**POST** `/api/user/change-password`
- **Access**: Authenticated (USER, ADMIN)
- **Description**: Change current user password
- **URL**: http://localhost:8080/api/user/change-password
- **Header**: `Authorization: Bearer {token}`

**Request Body:**
```json
{
  "username": "user1",
  "oldPassword": "old123",
  "newPassword": "new123"
}
```

---

## Product Management Endpoints (`/productos`)

### 1. Get All Products
**GET** `/api/productos`
- **Access**: Authenticated (USER, ADMIN)
- **Description**: Retrieve all products
- **URL**: http://localhost:8080/api/productos
- **Header**: `Authorization: Bearer {token}`

**Response:**
```json
[
  {
    "id": 1,
    "nombre": "Aspirina",
    "precio": 5.99,
    "cantidad": 100
  }
]
```

---

### 2. Get Product by ID
**GET** `/api/productos/{id}`
- **Access**: Authenticated (USER, ADMIN)
- **Description**: Get specific product details
- **URL**: http://localhost:8080/api/productos/1
- **Header**: `Authorization: Bearer {token}`

---

### 3. Create New Product
**POST** `/api/productos`
- **Access**: Admin only
- **Description**: Add new product to inventory
- **URL**: http://localhost:8080/api/productos
- **Header**: `Authorization: Bearer {admin_token}`

**Request Body:**
```json
{
  "nombre": "Ibuprofen",
  "precio": 7.50,
  "cantidad": 200
}
```

**Response (Success - 201):**
```json
{
  "id": 2,
  "nombre": "Ibuprofen",
  "precio": 7.50,
  "cantidad": 200
}
```

---

### 4. Update Product
**PUT** `/api/productos/{id}`
- **Access**: Admin only
- **Description**: Update existing product
- **URL**: http://localhost:8080/api/productos/1
- **Header**: `Authorization: Bearer {admin_token}`

**Request Body:**
```json
{
  "nombre": "Aspirina Premium",
  "precio": 6.99,
  "cantidad": 150
}
```

---

### 5. Delete Product
**DELETE** `/api/productos/{id}`
- **Access**: Admin only
- **Description**: Remove product from inventory
- **URL**: http://localhost:8080/api/productos/1
- **Header**: `Authorization: Bearer {admin_token}`

---

### 6. Bulk Upload Products (CSV)
**POST** `/api/productos/masivo`
- **Access**: Admin only
- **Description**: Upload multiple products from CSV file
- **URL**: http://localhost:8080/api/productos/masivo
- **Header**: `Authorization: Bearer {admin_token}`
- **Form Data**: `file` (multipart/form-data)

**CSV Format:**
```
nombre,precio,cantidad
Aspirina,5.99,100
Ibuprofen,7.50,200
Paracetamol,4.99,150
```

**Response:**
```json
"Successfully processed 3 records"
```

---

### 7. Get Product Count
**GET** `/api/productos/count`
- **Access**: Authenticated (USER, ADMIN)
- **Description**: Get total number of products
- **URL**: http://localhost:8080/api/productos/count
- **Header**: `Authorization: Bearer {token}`

---

## Admin Endpoints (`/admin`)

### 1. Admin Test
**GET** `/api/admin/test`
- **Access**: Admin only
- **Description**: Test admin access
- **URL**: http://localhost:8080/api/admin/test
- **Header**: `Authorization: Bearer {admin_token}`

**Response:**
```json
{
  "message": "Admin endpoint working!",
  "status": "success"
}
```

---

### 2. Get Dashboard
**GET** `/api/admin/dashboard`
- **Access**: Admin only
- **Description**: Get admin dashboard information
- **URL**: http://localhost:8080/api/admin/dashboard
- **Header**: `Authorization: Bearer {admin_token}`

---

### 3. Update Settings
**POST** `/api/admin/settings`
- **Access**: Admin only
- **Description**: Update system settings
- **URL**: http://localhost:8080/api/admin/settings
- **Header**: `Authorization: Bearer {admin_token}`

**Request Body:**
```json
{
  "maxUploadSize": "10MB",
  "sessionTimeout": "30"
}
```

---

### 4. Get System Information
**GET** `/api/admin/system-info`
- **Access**: Admin only
- **Description**: Get system and server information
- **URL**: http://localhost:8080/api/admin/system-info
- **Header**: `Authorization: Bearer {admin_token}`

**Response:**
```json
{
  "javaVersion": "21.0.1",
  "osName": "Windows 11",
  "processorCount": 8,
  "totalMemory": "1024 MB",
  "freeMemory": "512 MB"
}
```

---

## Testing with cURL or Postman

### Login Example:
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"password123"}'
```

### Get Products Example:
```bash
curl -X GET http://localhost:8080/api/productos \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

### Create Product Example:
```bash
curl -X POST http://localhost:8080/api/productos \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{
    "nombre": "Aspirin",
    "precio": 5.99,
    "cantidad": 100
  }'
```

---

## Access Control Summary

| Endpoint | Public | USER | ADMIN |
|----------|--------|------|-------|
| POST /auth/login | ✓ | ✓ | ✓ |
| POST /auth/validate | ✓ | ✓ | ✓ |
| GET /auth/test | ✓ | ✓ | ✓ |
| POST /user/register | ✓ | ✓ | ✓ |
| GET /user/profile | | ✓ | ✓ |
| GET /user/all | | | ✓ |
| GET /user/{id} | | | ✓ |
| PUT /user/{id} | | | ✓ |
| DELETE /user/{id} | | | ✓ |
| POST /user/change-password | | ✓ | ✓ |
| GET /productos | | ✓ | ✓ |
| GET /productos/{id} | | ✓ | ✓ |
| POST /productos | | | ✓ |
| PUT /productos/{id} | | | ✓ |
| DELETE /productos/{id} | | | ✓ |
| POST /productos/masivo | | | ✓ |
| GET /productos/count | | ✓ | ✓ |
| GET /admin/test | | | ✓ |
| GET /admin/dashboard | | | ✓ |
| POST /admin/settings | | | ✓ |
| GET /admin/system-info | | | ✓ |

---

## Error Codes

| Code | Meaning |
|------|---------|
| 200 | OK - Request successful |
| 201 | Created - Resource created successfully |
| 400 | Bad Request - Invalid request data |
| 401 | Unauthorized - Authentication required or failed |
| 403 | Forbidden - Access denied (insufficient permissions) |
| 404 | Not Found - Resource not found |
| 409 | Conflict - Resource already exists |
| 500 | Internal Server Error - Server error |

---

## Notes

1. All endpoints except `/auth/login`, `/auth/validate`, `/auth/test`, and `/user/register` require a valid JWT token in the `Authorization` header
2. Token format: `Authorization: Bearer {token}`
3. Tokens expire after 24 hours (86400000 milliseconds)
4. Default test credentials: `username: admin`, `password: password123` (update in database)
5. All requests should include `Content-Type: application/json` header for JSON payloads
