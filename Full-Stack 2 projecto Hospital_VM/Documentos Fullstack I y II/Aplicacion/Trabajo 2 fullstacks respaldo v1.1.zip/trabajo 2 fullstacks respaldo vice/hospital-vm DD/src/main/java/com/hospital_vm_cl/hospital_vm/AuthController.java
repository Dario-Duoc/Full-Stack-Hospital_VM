package com.hospital_vm_cl.hospital_vm;

import com.hospital_vm_cl.hospital_vm.dto.LoginRequest;
import com.hospital_vm_cl.hospital_vm.dto.AuthResponse;
import com.hospital_vm_cl.hospital_vm.service.UserService;
import com.hospital_vm_cl.hospital_vm.service.JwtService;
import com.hospital_vm_cl.hospital_vm.model.User;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private UserService userService;

    @Autowired
    private JwtService jwtService;

    @PostMapping("/login")
    public AuthResponse login(@RequestBody LoginRequest request) {

        User user = userService.findByUsername(request.getUsername());

        if (user == null || !request.getPassword().equals(user.getPassword())) {
            throw new RuntimeException("Credenciales inválidas");
        }

        String token = jwtService.generateToken(user.getUsername());

        return new AuthResponse(token);
    }
}